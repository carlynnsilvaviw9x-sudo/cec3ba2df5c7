// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Invert for slip distribution"); }
int main(){
  announce();
  return lionss_run_workload("saffron");
}
