// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Encode beacon frames"); }
int main(){
  announce();
  return lionss_run_workload("ferrite");
}
