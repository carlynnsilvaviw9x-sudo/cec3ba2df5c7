// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Burst-hold and release seats"); }
int main(){
  announce();
  return lionss_run_workload("ticketgate");
}
