// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Saga with compensation on step 3"); }
int main(){
  announce();
  return lionss_run_workload("sagaOrders");
}
