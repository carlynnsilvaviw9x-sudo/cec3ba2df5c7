// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Stitch spans into traces"); }
int main(){
  announce();
  return lionss_run_workload("juniper");
}
