// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("SPF and LSDB sync"); }
int main(){
  announce();
  return lionss_run_workload("ospfArea0");
}
