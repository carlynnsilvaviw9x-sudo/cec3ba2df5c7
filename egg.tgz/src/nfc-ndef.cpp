// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Encode NDEF URI record\n", stdout);
  return lionss_run_workload("nfc-ndef");
}
