// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(int argc, char** argv){
  (void)argc; (void)argv;
  std::printf("%s\n", "Audit against advisory db");
  std::fflush(stdout);
  return lionss_run_workload("DepAudit");
}
