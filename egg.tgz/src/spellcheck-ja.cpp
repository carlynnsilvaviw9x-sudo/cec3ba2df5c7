// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(int argc, char** argv){
  (void)argc; (void)argv;
  std::printf("%s\n", "Suggest corrections, edit distance 2");
  std::fflush(stdout);
  return lionss_run_workload("spellcheck-ja");
}
