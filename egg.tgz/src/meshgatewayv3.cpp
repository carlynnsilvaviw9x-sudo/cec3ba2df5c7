// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Gossip convergence check"); }
int main(){
  announce();
  return lionss_run_workload("meshgatewayv3");
}
