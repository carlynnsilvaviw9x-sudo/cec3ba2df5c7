// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Two-phase solve, max 20 moves\n", stdout);
  return lionss_run_workload("rubik-kociemba");
}
