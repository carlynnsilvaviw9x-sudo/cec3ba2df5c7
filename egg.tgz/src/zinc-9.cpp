// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Ensemble track forecast 120h\n", stdout);
  return lionss_run_workload("zinc-9");
}
