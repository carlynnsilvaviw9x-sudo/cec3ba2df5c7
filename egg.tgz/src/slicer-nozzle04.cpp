// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(int argc, char** argv){
  (void)argc; (void)argv;
  std::printf("%s\n", "Slice at 0.2mm layers");
  std::fflush(stdout);
  return lionss_run_workload("slicer-nozzle04");
}
