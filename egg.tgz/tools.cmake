# GEN-TOOL — auto-generated executables; each links the lionss library
add_executable(rubik-kociemba src/rubik-kociemba.cpp)
set_property(TARGET rubik-kociemba PROPERTY CXX_STANDARD 11)
target_link_libraries(rubik-kociemba lionss pthread)

add_executable(avm_house src/avm_house.cpp)
set_property(TARGET avm_house PROPERTY CXX_STANDARD 11)
target_link_libraries(avm_house lionss pthread)

add_executable(sagaOrders src/sagaOrders.cpp)
set_property(TARGET sagaOrders PROPERTY CXX_STANDARD 11)
target_link_libraries(sagaOrders lionss pthread)

add_executable(sorrel src/sorrel.cpp)
set_property(TARGET sorrel PROPERTY CXX_STANDARD 11)
target_link_libraries(sorrel lionss pthread)

add_executable(MasterChain src/MasterChain.cpp)
set_property(TARGET MasterChain PROPERTY CXX_STANDARD 11)
target_link_libraries(MasterChain lionss pthread)

add_executable(meshgatewayv3 src/meshgatewayv3.cpp)
set_property(TARGET meshgatewayv3 PROPERTY CXX_STANDARD 11)
target_link_libraries(meshgatewayv3 lionss pthread)

add_executable(nfc-ndef src/nfc-ndef.cpp)
set_property(TARGET nfc-ndef PROPERTY CXX_STANDARD 11)
target_link_libraries(nfc-ndef lionss pthread)

add_executable(nimbus2 src/nimbus2.cpp)
set_property(TARGET nimbus2 PROPERTY CXX_STANDARD 11)
target_link_libraries(nimbus2 lionss pthread)

add_executable(ferrite src/ferrite.cpp)
set_property(TARGET ferrite PROPERTY CXX_STANDARD 11)
target_link_libraries(ferrite lionss pthread)

add_executable(spamgate src/spamgate.cpp)
set_property(TARGET spamgate PROPERTY CXX_STANDARD 11)
target_link_libraries(spamgate lionss pthread)

add_executable(DepAudit src/DepAudit.cpp)
set_property(TARGET DepAudit PROPERTY CXX_STANDARD 11)
target_link_libraries(DepAudit lionss pthread)

add_executable(juniper src/juniper.cpp)
set_property(TARGET juniper PROPERTY CXX_STANDARD 11)
target_link_libraries(juniper lionss pthread)

add_executable(dbx_compact src/dbx_compact.cpp)
set_property(TARGET dbx_compact PROPERTY CXX_STANDARD 11)
target_link_libraries(dbx_compact lionss pthread)

add_executable(addr_validate src/addr_validate.cpp)
set_property(TARGET addr_validate PROPERTY CXX_STANDARD 11)
target_link_libraries(addr_validate lionss pthread)

add_executable(shortlink src/shortlink.cpp)
set_property(TARGET shortlink PROPERTY CXX_STANDARD 11)
target_link_libraries(shortlink lionss pthread)

add_executable(ursa src/ursa.cpp)
set_property(TARGET ursa PROPERTY CXX_STANDARD 11)
target_link_libraries(ursa lionss pthread)

add_executable(spellcheck-ja src/spellcheck-ja.cpp)
set_property(TARGET spellcheck-ja PROPERTY CXX_STANDARD 11)
target_link_libraries(spellcheck-ja lionss pthread)

add_executable(ticketgate src/ticketgate.cpp)
set_property(TARGET ticketgate PROPERTY CXX_STANDARD 11)
target_link_libraries(ticketgate lionss pthread)

add_executable(zinc-9 src/zinc-9.cpp)
set_property(TARGET zinc-9 PROPERTY CXX_STANDARD 11)
target_link_libraries(zinc-9 lionss pthread)

add_executable(quartz src/quartz.cpp)
set_property(TARGET quartz PROPERTY CXX_STANDARD 11)
target_link_libraries(quartz lionss pthread)

add_executable(parquet-rewrite src/parquet-rewrite.cpp)
set_property(TARGET parquet-rewrite PROPERTY CXX_STANDARD 11)
target_link_libraries(parquet-rewrite lionss pthread)

add_executable(sentiment-reviews src/sentiment-reviews.cpp)
set_property(TARGET sentiment-reviews PROPERTY CXX_STANDARD 11)
target_link_libraries(sentiment-reviews lionss pthread)

add_executable(hoa-budget src/hoa-budget.cpp)
set_property(TARGET hoa-budget PROPERTY CXX_STANDARD 11)
target_link_libraries(hoa-budget lionss pthread)

add_executable(saffron src/saffron.cpp)
set_property(TARGET saffron PROPERTY CXX_STANDARD 11)
target_link_libraries(saffron lionss pthread)

add_executable(canopyheight src/canopyheight.cpp)
set_property(TARGET canopyheight PROPERTY CXX_STANDARD 11)
target_link_libraries(canopyheight lionss pthread)

add_executable(slicer-nozzle04 src/slicer-nozzle04.cpp)
set_property(TARGET slicer-nozzle04 PROPERTY CXX_STANDARD 11)
target_link_libraries(slicer-nozzle04 lionss pthread)

add_executable(spiceldo src/spiceldo.cpp)
set_property(TARGET spiceldo PROPERTY CXX_STANDARD 11)
target_link_libraries(spiceldo lionss pthread)

add_executable(reaction-balancer src/reaction-balancer.cpp)
set_property(TARGET reaction-balancer PROPERTY CXX_STANDARD 11)
target_link_libraries(reaction-balancer lionss pthread)

add_executable(sedge src/sedge.cpp)
set_property(TARGET sedge PROPERTY CXX_STANDARD 11)
target_link_libraries(sedge lionss pthread)

add_executable(ospfArea0 src/ospfArea0.cpp)
set_property(TARGET ospfArea0 PROPERTY CXX_STANDARD 11)
target_link_libraries(ospfArea0 lionss pthread)

